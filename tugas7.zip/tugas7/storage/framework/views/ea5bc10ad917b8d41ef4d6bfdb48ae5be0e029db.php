<?php $__env->startSection('menu1','active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pt-4 bg-white">
        <div class="row">
            <div class="col-md-12">
                <h2>Tambah Data Sepatu</h2>
                <?php if(session()->has('message')): ?>
                    <div class="my-3">
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('sepatu.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-row py-4">
                        <div class="container">
                            <div class="row">
                                <div class="mb-4">
                                    <label for="merk_sepatu" class="form-label">Merk Sepatu</label>
                                    <input type="text" name="merk_sepatu" id="merk_sepatu" placeholder="Masukkan Merk Sepatu" class="form-control" value="<?php echo e(old('merk_sepatu')); ?>">
                                    <?php $__errorArgs = ['merk_sepatu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-4">
                                    <label for="tipe_sepatu" class="form-label">Tipe Sepatu</label>
                                    <select name="tipe_sepatu" id="tipe_sepatu" class="form-control">
                                        <option selected disabled>Pilih Tipe Sepatu</option>
                                        <option value="Sports" <?php echo e(old('tipe_sepatu') == "Sports" ? "selected" : ""); ?>>Sports</option>
                                        <option value="Lifestyle" <?php echo e(old('tipe_sepatu') == "Lifestyle" ? "selected" : ""); ?>>Lifestyle</option>
                                    </select>
                                    <?php $__errorArgs = ['tipe_sepatu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-4">
                                    <label for="ukuran" class="form-label">Ukuran Sepatu</label>
                                    <select name="ukuran" id="ukuran" class="form-control">
                                        <option selected disabled>Pilih Ukuran Sepatu</option>
                                        <option value="39" <?php echo e(old('ukuran') == "39" ? "selected" : ""); ?>>39</option>
                                        <option value="40" <?php echo e(old('ukuran') == "40" ? "selected" : ""); ?>>40</option>
                                        <option value="41" <?php echo e(old('ukuran') == "41" ? "selected" : ""); ?>>41</option>
                                        <option value="42" <?php echo e(old('ukuran') == "42" ? "selected" : ""); ?>>42</option>
                                        <option value="43" <?php echo e(old('ukuran') == "43" ? "selected" : ""); ?>>43</option>
                                    </select>
                                    <?php $__errorArgs = ['ukuran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-4">
                                    <label for="harga" class="form-label">Harga</label>
                                    <input type="text" name="harga" id="harga" placeholder="Masukkan Harga" class="form-control" value="<?php echo e(old('harga')); ?>">
                                    <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="d-flex flex-row-reverse py-3">
                                <button type="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OWNER\Documents\Kuliah\SEMESTER 5\FRAMEWORK\tugas7\resources\views/sepatu/create.blade.php ENDPATH**/ ?>