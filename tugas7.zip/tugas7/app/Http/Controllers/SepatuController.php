<?php

namespace App\Http\Controllers;

use App\Models\Sepatu;
use Illuminate\Http\Request;

class SepatuController extends Controller
{
    public function index()
    {
        $sepatus = Sepatu::get();
        return view('sepatu.index', compact('sepatus'));
    }

    public function create()
    {
        return view('sepatu.create');
    }

    public function store(Request $request)
    {
        $validate = $request->validate([
            'merk_sepatu' => 'required',
            'tipe_sepatu' => 'required',
            'ukuran' => 'required',
            'harga' => 'required|numeric'
        ]);

        Sepatu::create($validate);
        return redirect() -> route('sepatu.index') -> with('message', "Data sepatu {$validate['merk_sepatu']} berhasil ditambahkan");
    }

    public function destroy(Sepatu $sepatu)
    {
        $sepatu->delete();
        return redirect()->route('sepatu.index') -> with('message', "Data sepatu {$sepatu->nama_sepatu} berhasil dihapus");
    }

    public function edit(Sepatu $sepatu)
    {
        return view('sepatu.edit', compact('sepatu'));
    }

    public function update(Request $request, Sepatu $sepatu)
    {
        $validate = $request->validate([
            'merk_sepatu' => 'required',
            'tipe_sepatu' => 'required',
            'ukuran' => 'required',
            'harga' => 'required|numeric'
        ]);

        $sepatu -> update($validate);

        return redirect() -> route('sepatu.index') -> with('message', "Data sepatu {$sepatu->nama_sepatu} berhasil diubah");
    }

    public function show(Sepatu $sepatu)
    {
        return view('sepatu.show', compact('sepatu'));
    }
}
