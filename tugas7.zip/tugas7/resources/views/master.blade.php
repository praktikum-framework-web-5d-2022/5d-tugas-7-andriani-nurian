<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MyShoes</title>
    <style>
        .bg {
            background-color: blue;
        }
    </style>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg">
        <div class="container">
            <a href="/customer" class="navbar-brand">
                My Shoes
            </a>
        </div>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link @yield('menu')" href="/customer">Data Customer</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @yield('menu1')" href="/sepatu">Data Sepatu</a>
            </li>
        </ul>
    </nav>
    @yield('content')
</body>
</html>
