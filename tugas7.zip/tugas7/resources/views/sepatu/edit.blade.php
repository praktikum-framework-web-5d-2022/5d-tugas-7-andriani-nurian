@extends('master')
@section('menu1','active')

@section('content')
    <div class="container pt-4 bg-white">
        <div class="row">
            <div class="col-md-12">
                <h2>Edit Data</h2>
                @if (session()->has('message'))
                    <div class="my-3">
                        <div class="alert alert-success">
                            {{session()->get('message')}}
                        </div>
                    </div>
                @endif
                <form action="{{route('sepatu.update', ['sepatu' => $sepatu->id])}}" method="POST">
                    @method('PATCH')
                    @csrf
                    <div class="form-row py-4">
                        <div class="container">
                            <div class="row">
                                <div class="mb-4">
                                    <label for="merk_sepatu" class="form-label">Merk Sepatu</label>
                                    <input type="text" name="merk_sepatu" id="merk_sepatu" placeholder="Masukkan Merk Sepatu" class="form-control" value="{{old('merk_sepatu')}}">
                                    @error('merk_sepatu')
                                        <div class="text-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                <div class="mb-4">
                                    <label for="tipe_sepatu" class="form-label">Tipe Sepatu</label>
                                    <select name="tipe_sepatu" id="tipe_sepatu" class="form-control">
                                        <option selected disabled>Pilih Tipe Sepatu</option>
                                        <option value="Sports" {{old('tipe_sepatu') == "Sports" ? "selected" : ""}}>Sports</option>
                                        <option value="Lifestyle" {{old('tipe_sepatu') == "Lifestyle" ? "selected" : ""}}>Lifestyle</option>
                                    </select>
                                    @error('tipe_sepatu')
                                        <div class="text-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                <div class="mb-4">
                                    <label for="ukuran" class="form-label">Ukuran Sepatu</label>
                                    <select name="ukuran" id="ukuran" class="form-control">
                                        <option selected disabled>Pilih Ukuran Sepatu</option>
                                        <option value="39" {{old('ukuran') == "39" ? "selected" : ""}}>39</option>
                                        <option value="40" {{old('ukuran') == "40" ? "selected" : ""}}>40</option>
                                        <option value="41" {{old('ukuran') == "41" ? "selected" : ""}}>41</option>
                                        <option value="42" {{old('ukuran') == "42" ? "selected" : ""}}>42</option>
                                        <option value="43" {{old('ukuran') == "43" ? "selected" : ""}}>43</option>
                                    </select>
                                    @error('ukuran')
                                        <div class="text-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                <div class="mb-4">
                                    <label for="harga" class="form-label">Harga</label>
                                    <input type="text" name="harga" id="harga" placeholder="Masukkan Harga" class="form-control" value="{{old('harga')}}">
                                    @error('harga')
                                        <div class="text-danger">{{$message}}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="d-flex flex-row-reverse py-3">
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
