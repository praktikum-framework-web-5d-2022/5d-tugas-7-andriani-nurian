@extends('master')
@section('menu1','active')

@section('content')
    <div class="container pt-4 bg-white">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between">
                    <h2>Data Sepatu</h2>
                    <form class="form-inline">
                        <a href="{{route('sepatu.create')}}" class="btn btn-primary">Tambah</a>
                    </form>
                </div>
                <div class="py-4">
                    @if (session()->has('message'))
                        <div class="my-3">
                            <div class="alert alert-success">
                                {{session()->get('message')}}
                            </div>
                        </div>
                    @endif
                </div>
                <div class="table-responsive bdr " >
                    <table class="table table-striped">
                        <thead class="heading text-black">
                            <tr align="center">
                                <th>#</th>
                                <th>Merk Sepatu</th>
                                <th>Tipe Sepatu</th>
                                <th>Ukuran</th>
                                <th>Harga (Rp.)</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($sepatus as $sepatu)
                                <tr align="center">
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$sepatu->merk_sepatu}}</td>
                                    <td>{{$sepatu->tipe_sepatu}}</td>
                                    <td>{{$sepatu->ukuran}}</td>
                                    <td>{{$sepatu->harga}}</td>
                                    <td>
                                        <div class="d-flex justify-content-around">
                                            <a href="{{route('sepatu.edit', ['sepatu'=>$sepatu->id])}}" class="btn btn-warning btn-block" >Edit</a>
                                            <form action="{{route('sepatu.destroy', ['sepatu'=>$sepatu->id])}}" method="POST" class="ms-1">
                                                @method('DELETE')
                                                @csrf
                                                <button type="submit" class="btn btn-danger">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <td colspan="11">Tidak ada data...</td>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
