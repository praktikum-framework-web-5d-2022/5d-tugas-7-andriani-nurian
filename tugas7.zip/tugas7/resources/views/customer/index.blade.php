@extends('master')
@section('menu','active')

@section('content')
    <div class="container pt-4 bg-white">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between">
                    <h2>Data Customer</h2>
                    <form class="form-inline">
                        <a href="{{route('customer.create')}}" class="btn btn-primary">Tambah</a>
                    </form>
                </div>
                <div class="py-4">
                    @if (session()->has('message'))
                        <div class="my-3">
                            <div class="alert alert-success">
                                {{session()->get('message')}}
                            </div>
                        </div>
                    @endif
                </div>
                <div class="table-responsive bdr " >
                    <table class="table table-striped">
                        <thead class="heading text-black">
                            <tr align="center">
                                <th>#</th>
                                <th>Nama Customer</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($customers as $customer)
                                <tr align="center">
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$customer->nama}}</td>
                                    <td>{{$customer->alamat}}</td>
                                    <td>
                                        <div class="d-flex justify-content-around">
                                            <a href="{{route('customer.edit', ['customer'=>$customer->id])}}" class="btn btn-warning btn-block" >Edit</a>
                                            <form action="{{route('customer.destroy', ['customer'=>$customer->id])}}" method="POST" class="ms-1">
                                                @method('DELETE')
                                                @csrf
                                                <button type="submit" class="btn btn-danger">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <td colspan="11">Tidak ada data...</td>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
