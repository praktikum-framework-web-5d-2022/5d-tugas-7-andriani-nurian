@extends('master')
@section('menu','active')

@section('content')
    <div class="container pt-4 bg-white">
        <div class="row">
            <div class="col-md-12">
                <h2>Edit Data</h2>
                @if (session()->has('message'))
                    <div class="my-3">
                        <div class="alert alert-success">
                            {{session()->get('message')}}
                        </div>
                    </div>
                @endif
                <form action="{{route('customer.update', ['customer' => $customer->id])}}" method="POST">
                    @method('PATCH')
                    @csrf
                    <div class="form-row py-4">
                        <div class="container">
                            <div class="row">
                                <div class="col">
                                    <label for="nama" class="form-label">Nama Customer</label>
                                    <input type="text" name="nama" id="nama" placeholder="Masukkan Nama Customer" class="form-control" value="{{old('nama')}}">
                                    @error('nama')
                                        <div class="text-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                <div>
                                    <label for="alamat" class="form-label">Alamat Customer</label>
                                    <textarea name="alamat" id="alamat" class="form-control" placeholder="Masukkan Alamat Customer">{{old('alamat')}}</textarea>
                                    @error('alamat')
                                        <div class="text-danger">{{$message}}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="d-flex flex-row-reverse py-3">
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
